

public class increament_decreament {
    public static void main(String[] args){
        int a=12,b=67;
        int result1,result2;
        System.out.println("value of a:"+ a);
        result1=++a;
        System.out.println("after increament"+ result1);
        System.out.println("value of a:"+a);
        System.out.println("value of b:"+b);
        result2=--b;
        System.out.println("after decrement:"+ result2);
        System.out.println("value of b:"+b);
      
        
        
        
        }
        
    
}
