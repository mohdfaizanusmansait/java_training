

public class square_pattern {
    public static void main(String[] args){
        int size=5;
        for(int i=0;i<size;i++)//i=0;0<5
        {
        for(int j=0;j<size;j++)
        {
        System.out.print("*");
        }
        System.out.println();
        }
        
        
        
        }
    
}
