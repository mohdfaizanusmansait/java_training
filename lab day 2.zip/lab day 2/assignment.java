public class assignment {
    public static void main(String[] args)
  {
    int a=12;
    int var;
    var=a;
    System.out.println("var using=:"+var);
    var+=a;
    System.out.println("var using=:"+var);
    var*=a;
    System.out.println("var using-=:"+var);
    var/=a;
    System.out.println("var using/=:"+var);
    var%=a;
    System.out.println("var using%=:"+var);
     }

    
}
