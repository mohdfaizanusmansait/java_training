

public class matrix {public static void main(String args[]) {
	int[][] matrix={{2,3,4},{5,6,4}};
	for(int[] row:matrix){
	System.out.println(row+" ");
}
}

    
}
